import yt_dlp

while True:
    link = input("Url: ")
    
    if link == "":
        print("Meh")
        break

    opcoes = {
   'outtmpl': '%(title)s.mp3' 
    }

    with yt_dlp.YoutubeDL(opcoes) as ydl:
        ydl.download([link])
   
